#!/bin/sh

# Helper script that generates JS doc for the front-end

jsdoc -p -d=jsdoc js/*.js
